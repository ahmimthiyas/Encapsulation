/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package imthi.encapsulation;

/**
 *
 * @author imthi
 */




import java.util.Scanner;
public class BankAccess {
    


    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        BankAccount account = new BankAccount("AC-01-5432", 0, "User");

        int choice;
        boolean running = true;

        System.out.println("Welcome to Bank System ");

        while (running) {
            System.out.println("MENU ");
            System.out.println("1. Deposit");
            System.out.println("2. Withdraw");
            System.out.println("3. Check Current Balance");
            System.out.println("4. Show Account Details");
            System.out.println("5. Exit");
            System.out.println("---");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {

                case 1:
                    System.out.print("Enter amount to deposit: ");
                    double dep = sc.nextDouble();
                    account.deposit(dep);
                    break;

                case 2:
                    System.out.print("Enter amount to withdraw: ");
                    double wd = sc.nextDouble();
                    account.withdraw(wd);
                    break;

                case 3:
                    System.out.println("Current Balance: " + account.getBalance());
                    break;

                case 4:
                    System.out.println(" Account Details");
                    System.out.println("Account Number: " + account.getAccountNumber());
                    System.out.println("Account Holder Name: " + account.getAccountHolderName());
                    System.out.println("Account Balance: " + account.getBalance());
                    break;

                case 5:
                    System.out.println("Exit Successful. Thank You!");
                    running = false;
                    break;

                default:
                    System.out.println("Invalid Choice! Try again.");
            }
        }

        sc.close();
    }
}

